# Accept file name and one string from user and return the frequency of that string from file.  
# Input : Demo.txt Marvellous  
# Search “Marvellous” in Demo.txt 

##########################################################################################

def freq(name,str1):
    file=open(name,"r")
    data=file.read()
    
    return data.count(str1)

def main():
    name=input("Enter the file name:")
    str1=input("Enter the string(word) to check: ")
    
    count=freq(name,str1)
    print("count of enterd string is:",count)
    
if __name__=="__main__":
    main()

