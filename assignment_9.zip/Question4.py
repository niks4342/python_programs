# Write a program which accept two file names from user and compare contents of both the  files. 
# If both the files contains same contents then display success otherwise display failure.  
# Accept names of both the files from command line.  
# Input : Demo.txt Hello.txt  
# Compare contents of Demo.txt and Hello.txt 


# #############################################################################################
from sys import*
import hashlib
import os

name1=argv[1]
name2=argv[2]


if((os.path.isfile(name1) and (os.path.isfile(name2)))==True):
    f1=hashlib.md5(open(name1,'rb').read()).hexdigest()
    print(f1)
    f2=hashlib.md5(open(name2,'rb').read()).hexdigest()
    print(f2)
    if(f1==f2):
        print("Success")
    else:
        print("Failure")
else:
    print("Invalid input")
