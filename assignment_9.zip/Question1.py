# 1.Write a program which accepts file name from user and check whether that file exists in
# current directory or not.
# Input : Demo.txt
# Check whether Demo.txt exists or not.

###########################################################################################
import os

name=input("Enter the file name:")

if (os.path.isfile(name)==True):
    print("file exist")
else:
    print("File not exist")