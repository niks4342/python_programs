# Write a program which accept file name from user and open that file and display the contents
# of that file on screen.
# Input : Demo.txt
# Display contents of Demo.txt on console.

##############################################################################3


name=input("Enter the file name:")

fd=open(name,"r")
data=fd.read()
print("Data in the file is:",data)
fd.close()