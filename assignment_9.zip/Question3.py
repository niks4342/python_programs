# 3.Write a program which accept file name from user and create new file named as Demo.txt and
# copy all contents from existing file into new file. Accept file name through command line
# arguments.
# Input : ABC.txt
# Create new file as Demo.txt and copy contents of ABC.txt in Demo.txt

##########################################################################################


from sys import*



name=argv[1]
fd=open("Demo.txt","r")
data=fd.read()
fd.close()

fd=open(name,"w")
fd.write(data)


