# Design automation script which accept two directory names and one file extension. Copy all  
# files with the specified extension from first directory into second directory. Second directory  
# should be created at run time.

############################################################################################

from sys import*
import os
import shutil

def func(path,destination,extention):
    files=os.listdir(path)
    
    for fname in files:
        ext=os.path.splitext(fname)
       
        if(ext[1]==extention):
            shutil.copy2(os.path.join(path,fname),destination)
    

def main():
    path="D:\\try\\py"
    destination=argv[1]#new
    extention=argv[2]
    
    src=os.path.abspath(os.path.join(path, os.pardir))
    source=os.path.join(src,destination)
    os.mkdir(source)

    func(path,source,extention)
    
    
if __name__=="__main__":
    main()