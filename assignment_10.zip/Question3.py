#  Design automation script which accept two directory names. Copy all files from first directory  
#  into second directory. Second directory should be created at run time

################################################################################################
from sys import*
import os
import shutil

def func(path,destination):
    files=os.listdir(path)
    
    for fname in files:
        shutil.copy2(os.path.join(path,fname),destination)
    

def main():
    path="D:\\try\\c_Files"
    destination=argv[1]#new
    
    src=os.path.abspath(os.path.join(path, os.pardir))
    source=os.path.join(src,destination)
    os.mkdir(source)

    func(path,source)
    
    
if __name__=="__main__":
    main()