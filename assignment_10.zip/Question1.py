# Design automation script which accept directory name and file extension from user. 
# Display all  files with that extension
#######################################################################################
import shutil
from sys import*
import os

def func(source,destination,extention):
    l=os.listdir(source)
    os.makedirs(source+'/'+destination)
    for file in l:
        ext=os.path.splitext(file)
        if(ext==extention):
            shutil.move(source+'/'+file,source+'/'+destination+'/'+file)

def main():
    source="D:/try"
    destination=argv[1]
    extention=argv[2]
    
    func(source,destination,extention)

if __name__=="__main__":
    main()

















# for file in file_list:
#     split_tup = os.path.splitext(file)
#     print(split_tup)
#     if(split_tup[1]==argv[2]):
#         file_name.append(file)
#         for f in file_name:
#             shutil.move(f, "destination")
  
# for f in file_name:
#     shutil.move(f, "destination")
    
  
