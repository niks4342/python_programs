import shutil
from sys import*
import os

def func(source,extention1,extention2):
    for filename in os.listdir(source):
        filename = os.path.join(source,filename)
        
        ext = os.path.splitext(filename)
        if(ext[1]==extention1):
            newname = filename.replace(extention1,extention2)
            os.rename(filename, newname)
        elif(ext[1]==extention2):
            newname = filename.replace(extention1,extention2)
            os.rename(filename, newname)

def main():
    source="D:/try/ext2"
    extention1=argv[1]
    extention2=argv[2]
    
    func(source,extention1,extention2)

if __name__=="__main__":
    main()

