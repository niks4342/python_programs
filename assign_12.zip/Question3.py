# . Design automation script which accept directory name from user and 
# create log file in that  directory which contains information of running 
# processes as its name, PID, Username. 

#################################################################33333



import psutil
from sys import *
import time

def Display():
    
    listProc=[]
        
    for proc in psutil.process_iter():
        try:
            pinfo=proc.as_dict(attrs=['pid','name','username'])
            listProc.append(pinfo)
            
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
        
    return listProc
    
def Log(listproc):
    
    separator='-'*80
    
    fd=open("Log_File","a")
    fd.write(separator+"\n")
    fd.write("Process Logger:"+time.ctime()+"\n")
    fd.write(separator+"\n")
    
    for elem in listproc:
        fd.write("%s\n"%elem)
          
    
        
    

def main():
    
    print("Script name:",argv[0])
    
    listProc=Display()
    
    Log(listProc)

if __name__=="__main__":
    main()