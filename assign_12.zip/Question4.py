import psutil
from sys import *
import time
from urllib.request import urlopen
from email.message import EmailMessage
import datetime
import smtplib
import schedule



def Mailsender():
   
    print("Current time is:",datetime.datetime.now())
    msg=EmailMessage()
    msg['Subject']="Process Logger"
    msg['From']="Nikita Birajdar"
    msg['To']="shridevib111@gmail.com"

    with open("Log_file") as File:
        data=File.read()
        msg.set_content(data)

    server=smtplib.SMTP_SSL('smtp.gmail.com',465)
    server.login("shridevib111@gmail.com",'nikita@111')

    server.send_message(msg)
    server.quit()
        
        
        

def Display():
    
    listProc=[]
        
    for proc in psutil.process_iter():
        try:
            pinfo=proc.as_dict(attrs=['pid','name','username'])
            listProc.append(pinfo)
            
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
        
    return listProc
    
def Log(listproc):
    
    separator='-'*80
    
    fd=open("Log_File","a")
    fd.write(separator+"\n")
    fd.write("Process Logger:"+time.ctime()+"\n")
    fd.write(separator+"\n")
    
    for elem in listproc:
        fd.write("%s\n"%elem)
          
    
        
def main():
    
    print("Script name:",argv[0])
    
    listProc=Display()
    Log(listProc)
    
    schedule.every(10).seconds.do(Mailsender)
   
    
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__=="__main__":
    main()