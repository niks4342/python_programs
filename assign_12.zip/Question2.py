# Design automation script which accept process name and display information of that process if  it is running.

###################################################################################################################

import psutil
from sys import *

def Display(Name):
    for proc in psutil.process_iter():
        try:
            if Name.lower() in proc.name().lower():
                
                processName = proc.name()
                processID = proc.pid
                username=proc.username
                print("Name",processName , ' PID', processID,"Username",username)
           
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    


def main():
    name=argv[1]
    print("Information of running process:",name)
    
    print("Script name:",argv[0])
    print("Number of arguments accepted:",len(argv)-1)
    
    if ((len(argv))>3) or ((len(argv))<2):
        print("Invalid number of arguments")
        print("* Use -u flag for usage ")
        print("* Use -h flag for help")
        exit()
        
    if (argv[1]=="-u") or (argv[1]=="-U"):
        print("Usage:Script is used to perform addition of two numbres")
        exit()
        
    if(argv[1]=="-h") or (argv[1]=="-H"):
        print("Help: Name_of_Script first_argument second_argument")
        print("First_argument:any numeric value")
        print("Second_argument:any numeric value")
        exit()
    
    Display(name)

if __name__=="__main__":
    main()