# Design automation script which display information of running processes as its name, PID,  Username.

import psutil

def Display():
    
    for proc in psutil.process_iter():
        try:
            
            processName = proc.name()
            processID = proc.pid
            username=proc.username
            print("Name",processName , ' PID', processID,"Username",username)
           
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    

def main():
    
    print("Information of running process:")
    
    Display()
    
  
    

if __name__=="__main__":
    main()