# Design automation script which accept directory name and display checksum of all files.   
# Usage : DirectoryChecksum.py “Demo”  
# Demo is name of directory.

###########################################################################################

import hashlib
import os
from pathlib import Path 
def CheckSum(directory):
    file_list=os.listdir(directory)
 
    for file in file_list:
        file_name=Path(os.path.join(directory,file))
        
        if(file_name.is_file()  or  file_name.is_dir()):
            FileHash=hashlib.md5(open(file_name,'rb').read()).hexdigest()
            print(FileHash)
           

def main():

    directory="D:\\try\\c_Files"
      
    CheckSum(directory)



    
    
if __name__=="__main__":
    main()