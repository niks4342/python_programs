# Design automation script which accept directory name and write names of duplicate files from  
# that directory into log file named as Log.txt. Log.txt file should be created into current  directory.

###################################################################################################

from sys import*
import os
import hashlib
from pathlib import Path 


path=argv[1]
unique=dict()


file_list=os.listdir(path)

for file in file_list:
    file_N=file
    file_name=Path(os.path.join(path,file))
    
    if file_name.is_file() or file_name.is_dir():
        
        FileHash=hashlib.md5(open(file_name,'rb').read()).hexdigest()
        
        if FileHash not in unique:
            unique[FileHash]=file_name
        else:
            fd=open("Log.txt","a")
            fd.write(file_N)
            fd.write("\n")
            fd.close()
    else:
        print("Operation get failed")